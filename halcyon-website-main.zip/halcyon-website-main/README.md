# E-Halycon Website

Website for E-Halycon

The code for the fog effect on the homepage is based off of [spite/CSS3DClouds](https://github.com/spite/CSS3DClouds).
